# Assignment 01 - Attendance Tracker

**Name:** Sandhya Kumari Kushwaha
**Program:** MCA (AI & ML)  
**Semester:** I  
**Faculty:** Ms. Neha Kaushik  
**Course:** Programming for Problem Solving Using Python  
**Session:** 2025-26  

---

## About the Project
This is a simple command-line Attendance Tracker made using Python.  
It lets you record student names and their check-in times, view attendance summaries, check absentees, and even save the report to a file.

---

## What I Learned
- Using input() and loops to take multiple entries  
- Storing data in dictionary and JSON file  
- Applying if...else conditions for validation  
- Displaying data neatly using f-strings  
- Writing data to text files

---

## Files in Project
attendance_tracker/
│
├── tracker.py              # Main Python code
├── attendance_data.json    # Stores attendance data
├── attendance_log.txt      # Saved report (after running)
└── README.md               # This file

---

## How to Run
1. Open terminal or command prompt.
2. Go to the folder where tracker.py is saved.
3. Run the file:
   python tracker.py
   ```
if you use VS code studio then drag you file into vs code and then  just press f5
--- 

## Example Output
Welcome to the Python Attendance Tracker
How many students do you want to record? 2

Entry 1:
Enter student name: Riya
Enter check-in time: 09:10 AM

Entry 2:
Enter student name: Arjun
Enter check-in time: 09:20 AM

Attendance recorded successfully!

--- Attendance Summary ---
Student Name   Check-in Time
-----------------------------------
Riya           09:10 AM
Arjun          09:20 AM
-----------------------------------
Total Students Present: 2

---

## Optional Features
- Absentee check by entering total number of students
- Save attendance report to attendance_log.txt
