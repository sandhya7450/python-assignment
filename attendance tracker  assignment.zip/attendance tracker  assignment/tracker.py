1# =============================================
# Name: Sandhya Kumari Kushwaha
# Date: 09-11-2025
# Assignment No: 01
# Course: Programming for Problem Solving Using Python
# Faculty: Ms. Neha Kaushik
# =============================================

import json
from datetime import datetime

data_file = "attendance_data.json"

def load_data():
    try:
        with open(data_file, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_data(attendance):
    with open(data_file, "w") as f:
        json.dump(attendance, f, indent=4)

def take_attendance():
    attendance = load_data()
    print("\n--- Record Attendance ---")

    try:
        total = int(input("How many students do you want to record? "))
    except ValueError:
        print("Please enter a valid number.")
        return

    for i in range(total):
        print(f"\nEntry {i+1}:")
        name = input("Enter student name: ").strip()
        if name == "":
            print("Name cannot be empty.")
            continue
        if name in attendance:
            print("This student is already marked present.")
            continue

        time = input("Enter check-in time (e.g., 09:15 AM): ").strip()
        if time == "":
            print("Time cannot be empty.")
            continue

        attendance[name] = time

    save_data(attendance)
    print("\nAttendance recorded successfully!\n")

def show_summary():
    attendance = load_data()
    if not attendance:
        print("No attendance data found.")
        return

    print("\n--- Attendance Summary ---")
    print("Student Name\tCheck-in Time")
    print("-" * 35)
    for name, time in attendance.items():
        print(f"{name}\t{time}")
    print("-" * 35)
    print(f"Total Students Present: {len(attendance)}")

def absentee_check():
    attendance = load_data()
    if not attendance:
        print("No attendance data found.")
        return

    try:
        total = int(input("Enter total number of students in class: "))
    except ValueError:
        print("Invalid number.")
        return

    present = len(attendance)
    absent = total - present

    print(f"Total Present: {present}")
    print(f"Total Absent: {absent}")

def save_report():
    attendance = load_data()
    if not attendance:
        print("No attendance data to save.")
        return

    choice = input("Do you want to save report to file? (yes/no): ").lower()
    if choice != "yes":
        return

    try:
        total = int(input("Enter total number of students in class: "))
    except ValueError:
        total = len(attendance)

    present = len(attendance)
    absent = total - present

    with open("attendance_log.txt", "w") as file:
        file.write("Attendance Report\n")
        file.write("========================\n")
        for name, time in attendance.items():
            file.write(f"{name}\t{time}\n")
        file.write("========================\n")
        file.write(f"Total Present: {present}\n")
        file.write(f"Total Absent: {absent}\n")
        file.write(f"Report Generated On: {datetime.now()}\n")

    print("\nReport saved as 'attendance_log.txt' successfully!\n")

def main():
    print("\n========================================")
    print(" Welcome to the Python Attendance Tracker ")
    print("========================================")
    print("This tool helps to record and manage student attendance.\n")

    while True:
        print("\n1. Record Attendance")
        print("2. Show Attendance Summary")
        print("3. Absentee Validation")
        print("4. Save Report to File")
        print("5. Exit")

        choice = input("\nEnter your choice (1-5): ")

        if choice == "1":
            take_attendance()
        elif choice == "2":
            show_summary()
        elif choice == "3":
            absentee_check()
        elif choice == "4":
            save_report()
        elif choice == "5":
            print("\nThank you! Exiting the Attendance Tracker.")
            break
        else:
            print("Invalid choice. Please enter a number between 1 to 5.")

if __name__ == "__main__":
    main()
